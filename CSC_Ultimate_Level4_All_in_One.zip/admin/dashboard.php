<?php
session_start();
if(!isset($_SESSION['admin'])){
header("Location: login.php");
}
include "../config.php";

$total = $conn->query("SELECT COUNT(*) as total FROM applications")->fetch_assoc()['total'];
$result = $conn->query("SELECT * FROM applications ORDER BY id DESC");
?>

<h2>Admin Dashboard</h2>
<h3>Total Applications: <?php echo $total; ?></h3>

<a href="../export_csv.php">Export CSV</a> |
<a href="logout.php">Logout</a>

<hr>

<table border="1" width="100%">
<tr>
<th>ID</th>
<th>Name</th>
<th>Mobile</th>
<th>Service</th>
<th>Date</th>
<th>Action</th>
</tr>

<?php while($row=$result->fetch_assoc()){ ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['name']; ?></td>
<td><?php echo $row['mobile']; ?></td>
<td><?php echo $row['service']; ?></td>
<td><?php echo $row['date']; ?></td>
<td>
<a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Delete?')">Delete</a>
</td>
</tr>
<?php } ?>
</table>