<?php
session_start();
include "../config.php";

if(isset($_POST['login'])){

$stmt = $conn->prepare("SELECT password FROM admins WHERE username=?");
$stmt->bind_param("s", $_POST['username']);
$stmt->execute();
$result = $stmt->get_result();

if($row = $result->fetch_assoc()){
if(password_verify($_POST['password'],$row['password'])){
$_SESSION['admin']=true;
header("Location: dashboard.php");
}
}
}
?>

<form method="POST">
<h2>Admin Login</h2>
<input type="text" name="username" placeholder="Username" required>
<input type="password" name="password" placeholder="Password" required>
<button name="login">Login</button>
</form>