<?php
$conn = new mysqli("localhost","root","","janseva_db");
if($conn->connect_error){
die("Connection Failed");
}
?>