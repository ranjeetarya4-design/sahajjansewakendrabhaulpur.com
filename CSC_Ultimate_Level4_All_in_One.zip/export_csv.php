<?php
include "config.php";

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="applications.csv"');

$output = fopen("php://output","w");
fputcsv($output, ['ID','Name','Mobile','Service','Date']);

$result = $conn->query("SELECT * FROM applications");

while($row=$result->fetch_assoc()){
fputcsv($output,$row);
}
fclose($output);
?>