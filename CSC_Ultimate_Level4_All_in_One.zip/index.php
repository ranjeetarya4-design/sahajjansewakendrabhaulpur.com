<!DOCTYPE html>
<html>
<head>
<title>CSC Jan Seva Portal</title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="header">
<img src="assets/csc_logo.png" height="80">
<h1>CSC Jan Seva Kendra</h1>
<img src="assets/profile.png" height="80" style="border-radius:50%;">
</div>

<div class="form-box">
<form method="POST" action="save.php">
<input type="text" name="name" placeholder="Applicant Name" required>
<input type="text" name="mobile" placeholder="Mobile Number" required>

<select name="service" required>
<option value="">Select Service</option>
<option>Aadhar Update</option>
<option>PAN Card</option>
<option>Income Certificate</option>
<option>Residence Certificate</option>
<option>Caste Certificate</option>
</select>

<button type="submit">Submit Application</button>
</form>
</div>

</body>
</html>