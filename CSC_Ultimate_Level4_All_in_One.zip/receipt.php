<?php
include "config.php";
$id = $_GET['id'];
$result = $conn->query("SELECT * FROM applications WHERE id=$id");
$row = $result->fetch_assoc();
?>

<h2>Application Receipt</h2>
<p>Name: <?php echo $row['name']; ?></p>
<p>Mobile: <?php echo $row['mobile']; ?></p>
<p>Service: <?php echo $row['service']; ?></p>
<p>Date: <?php echo $row['date']; ?></p>
<a href="index.php">Back</a>