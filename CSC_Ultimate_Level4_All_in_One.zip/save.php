<?php
include "config.php";

$stmt = $conn->prepare("INSERT INTO applications (name,mobile,service) VALUES (?,?,?)");
$stmt->bind_param("sss", $_POST['name'], $_POST['mobile'], $_POST['service']);
$stmt->execute();

echo "<script>alert('Application Submitted Successfully');window.location='receipt.php?id=".$stmt->insert_id."';</script>";
?>